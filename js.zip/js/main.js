(function() {

	$('#join').on('click', function() {

		$.getJSON('register-player.php?name=fake', function() {
			console.log('join the game');

		});
	});

	$('#killswitch').on('click', function() {
		$.getJSON('reset_game.php', function() {
			console.log('killed it');
		});
	});

	$('#deal').on('click', function() {
		$.getJSON('deal_cards.php', function() {
			console.log('dealed out da cards');

			$.getJSON("get_hand.php", function(data) {
				data.forEach(function(v) {
					var imgElem = $('<img class="card" src="'+ v.filePath +'">').appendTo('.hand');

					imgElem.click(function(ev) {
						$.getJSON("place_card.php?suit=" + v.suit + "&rank=" + v.rank + "&value=" + v.value, function(isPlayable){
							console.log('CrazyEight:', isPlayable.eight, 'Rank or suit:', isPlayable.playable);

							if (isPlayable.eight === true) {
								//$('<img class="card" src="'+ v.filePath +'">').appendTo('.container');
								// $('.container #topcard' ).replaceWith('<img class="card" src="'+ data.filePath +'">');
								replaceTopCard(v.filePath);
							} else if (isPlayable.playable === true) {
								//$('<img class="card" src="'+ v.filePath +'">').appendTo('.container');
								// $('.container #topcard' ).replaceWith('<img class="card" src="'+ data.filePath +'">');
								replaceTopCard(v.filePath);
							} else {
								return false;
							}

						});
					});
				});
			});

		});


	});



	function replaceTopCard(filePath) {
		$('.container #topcard' ).replaceWith('<img id="topcard" class="card" src="'+ filePath +'">');
	}



	$('body').on('click', '.backside', function(){
		$.getJSON("get_card.php", function(data) {

			data.forEach(function(v) {
				$('<img class="card" src="'+ v.filePath +'">').appendTo('.container');

				// Place Card from deck
				$.getJSON("place_card.php?suit=" + v.suit + "&rank=" + v.rank + "&value=" + v.value, function(data){
					console.log('CrazyEight: ', data.eight, 'Rank || suit: ', data.playable);

						if (data.eight === true) {
							// $('.container #topcard' ).replaceWith('<img class="card" src="'+ data.filePath +'">');
							replaceTopCard(v.filePath);
						} else if (data.playable === true) {
							// $('.container #topcard' ).replaceWith('<img class="card" src="'+ data.filePath +'">');
							replaceTopCard(v.filePath);
						} else {
							$.getJSON("save_to_hand.php?suit=" + v.suit + "&rank=" + v.rank + "&value=" + v.value, function(data){
								// $('<img class="card" src="'+ v.filePath +'">').appendTo('.hand');
								replaceTopCard(v.filePath);
							});
						}
				});
			});
		});
	});

	function checkGameState() {
		$.getJSON("game_state.php", function(data) {
			//console.log(data);

			// var completeHand = '<div class="hand">';
			// // var completeHand = '';

			// // FRÅGA TOBIAS!!!!
			// data.hand.forEach(function(v){
   //      completeHand += '<img class="card" src="'+ v.filePath +'">';
   //      console.log(v.hand);
			// });

			// completeHand += '</div>';

			// $('.hand').replaceWith(completeHand);

			var completeHand = $('<div class="hand"></div>');
			data.hand.forEach(function(v){
				var imgEl = $('<img class="card" src="'+ v.filePath +'">');
				imgEl.click(function(ev) {
						$.getJSON("place_card.php?suit=" + v.suit + "&rank=" + v.rank + "&value=" + v.value, function(isPlayable){
							//console.log('CrazyEight:', isPlayable.eight, 'Rank or suit:', isPlayable.playable);

							if (isPlayable.eight === true) {
								//$('<img class="card" src="'+ v.filePath +'">').appendTo('.container');
								// $('.container #topcard' ).replaceWith('<img class="card" src="'+ data.filePath +'">');
								replaceTopCard(v.filePath);
							} else if (isPlayable.playable === true) {
								//$('<img class="card" src="'+ v.filePath +'">').appendTo('.container');
								// $('.container #topcard' ).replaceWith('<img class="card" src="'+ data.filePath +'">');
								replaceTopCard(v.filePath);
							} else {
								return false;
							}

						});
					});
        completeHand.append(imgEl);
        console.log(v.hand);
			});


			$('.hand').replaceWith(completeHand);

			console.log(data.hand);
      console.log(data.turn, data.id);

			//$('<img class="card" src="'+ data.filePath +'">').appendTo('.container');
			// $('.container #topcard').replaceWith($('<img class="card" src="'+ data.filePath +'">'));
			replaceTopCard(data.playedCard.filePath);

			//data.hand innehåller spelarens hand
			//behöver appenda dem på handen i html

		});
	}

	setInterval(checkGameState, 1000);

})();
